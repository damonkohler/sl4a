local io = require 'io'
local json = require 'json'
local socket = require 'socket'
local P = {}

if _REQUIREDNAME == nil then
  android = P
else
  _G[_REQUIREDNAME] = P
end

local id = 0

function rpc(client, method, ...)
  assert(method, 'method param is nil')
  local rpc = {
    ['id'] = id,
    ['method'] = method,
    params = arg
  }
  local request = json.encode(rpc)
  client:send(request .. '\n')
  id = id + 1
  local response = client:receive('*l')
  local result = json.decode(response)
  if result.error ~= nil then
    print(result.error)
  end
  return result
end

local port = tonumber(os.getenv('AP_PORT'))
local client = socket.connect('localhost', port)
local meta = {
  __index = function(t, key)
    return function(...)
      return rpc(client, key, unpack(arg))
    end
  end
}

setmetatable(P, meta)

function P.dial(uri)
  return P.startActivity('android.intent.action.DIAL', uri)
end

function P.dialNumber(number)
  return P.dial('tel:' .. number)
end

function P.call(uri)
  return P.startActivity('android.intent.action.CALL', uri)
end

function P.callNumber(number)
  return P.call('tel:' .. number)
end

function P.view(uri)
  return P.startActivity('android.intent.action.VIEW', uri)
end

function P.map(query)
  return P.view('geo:0,0?q=' .. query)
end

function P.showContacts()
  return P.view('content://contacts/people')
end

function P.email()
  return P.view('mailto://')
end

function P.edit(uri)
  return P.startActivity('android.intent.action.EDIT', uri)
end

function P.pick(uri)
  return P.startActivityForResult('android.intent.action.PICK', uri)
end

function P.pickContact()
  return P.pick('content://contacts/people')
end

function P.pickPhone()
  return P.pick('content://contacts/phones')
end

function P.scanBarcode()
  return P.startActivityForResult('com.google.zxing.client.android.SCAN')
end

function P.captureImage()
  return P.startActivityForResult('android.media.action.IMAGE_CAPTURE')
end

function P.webSearch(query)
  return P.view('http://www.google.com/search?q=' .. query)
end

-- Everything above this line should be ported to every supported language.


-- Workaround for no sleep function in Lua.
function P.sleep(seconds)
  return os.execute('sleep ' .. seconds)
end

function P.printDict(d)
  for k, v in pairs(d) do print(k, v) end
end

function P.whoami()
  local f = assert(io.popen('id', 'r'))
  local s = assert(f:read('*a'))
  return string.match(s, 'uid=%d+%((.-)%)')
end

function P.ps()
  local f = assert(io.popen('ps', 'r'))
  local user = P.whoami()
  local procs = {}
  for line in f:lines() do
    if string.match(line, '^(.-)%s', 1) == user then
      local pid = string.match(line, '^.-%s+(%d+)', 1)
      local cmd = string.match(line, '%s+([^%s]+)$', 1)
      procs[pid] = cmd
    end
  end
  return procs
end

function P.kill(pid)
  os.execute('kill ' .. pid)
end

function P.killallmine()
  local procs = P.ps()
  local killcmd = 'kill '
  for pid, cmd in pairs(procs) do killcmd = killcmd .. pid end
  os.execute(killcmd)
end

return P
