require "android"
android.makeToast("Hello, Android!")
