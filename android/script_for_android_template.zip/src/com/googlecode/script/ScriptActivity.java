package com.googlecode.script;

import android.app.Activity;

public class ScriptActivity extends Activity {
}
