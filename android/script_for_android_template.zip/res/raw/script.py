import android
droid = android.Android()
droid.makeToast('Hello, Android!')
droid.vibrate(300)
