import android
import time
droid = android.Android()
droid.makeToast('Hello, Android!')
time.sleep(3)
droid.vibrate(300)
droid.setResultString(-1, 'Dummy RESULT!')