package com.dummy.fooforandroid;

import android.content.Context;

import com.google.ase.interpreter.InterpreterDescriptor;

public class FooDescriptor implements InterpreterDescriptor {

  public String getName() {
    // TODO Auto-generated method stub
    return null;
  }

  public String getNiceName() {
    // TODO Auto-generated method stub
    return null;
  }

  public String getExtension() {
    // TODO Auto-generated method stub
    return null;
  }

  public String getBinary() {
    // TODO Auto-generated method stub
    return null;
  }

  public String getPath(Context arg0) {
    // TODO Auto-generated method stub
    return null;
  }

  public int getVersion() {
    // TODO Auto-generated method stub
    return 0;
  }

  public String getEmptyParams() {
    // TODO Auto-generated method stub
    return null;
  }

  public String getExecuteCommand() {
    // TODO Auto-generated method stub
    return null;
  }

  public String getExecuteParams() {
    // TODO Auto-generated method stub
    return null;
  }

  public boolean hasInterpreterArchive() {
    // TODO Auto-generated method stub
    return false;
  }

  public String getInterpreterArchiveName() {
    // TODO Auto-generated method stub
    return null;
  }

  public String getInterpreterArchiveUrl() {
    // TODO Auto-generated method stub
    return null;
  }

  public boolean hasExtrasArchive() {
    // TODO Auto-generated method stub
    return false;
  }

  public String getExtrasArchiveName() {
    // TODO Auto-generated method stub
    return null;
  }

  public String getExtrasArchiveUrl() {
    // TODO Auto-generated method stub
    return null;
  }

  public boolean hasScriptsArchive() {
    // TODO Auto-generated method stub
    return false;
  }

  public String getScriptsArchiveName() {
    // TODO Auto-generated method stub
    return null;
  }

  public String getScriptsArchiveUrl() {
    // TODO Auto-generated method stub
    return null;
  }

}
