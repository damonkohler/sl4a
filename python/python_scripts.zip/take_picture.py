import android

droid = android.Android()
droid.cameraTakePicture('/sdcard/foo.jpg')
