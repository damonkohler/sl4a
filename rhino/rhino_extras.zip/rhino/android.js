/*
 * Copyright (C) 2009 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

var AP_PORT = java.lang.System.getenv("AP_PORT");

load('/sdcard/ase/extras/rhino/json2.js');

function Android() {

	this.connection = new java.net.Socket("127.0.0.1", AP_PORT),
	this.input = new java.io.BufferedReader(new java.io.InputStreamReader(this.connection.getInputStream(), "8859_1")),
	this.output = new java.io.PrintWriter(new java.io.OutputStreamWriter(new java.io.BufferedOutputStream(this.connection.getOutputStream()), "8859_1"), true),
	this.id = 0,

	this.rpc = function(method, args) {
		this.id += 1;
		var request = JSON.stringify({'id' : this.id, 'method' : method, 'params' : args});
		this.output.write(request + '\n');
		this.output.flush();
		var response = this.input.readLine();
		return eval("(" + response + ")");
	},

	this.__noSuchMethod__ = function(id, args) {
		var response = this.rpc(id, args);
		if (response.error != null) {
			throw response.error;
		}
		return response.result;
	}
}
