load("/sdcard/ase/extras/rhino/android.js");
var droid = new Android();
droid.makeToast("Hello, Android!");
