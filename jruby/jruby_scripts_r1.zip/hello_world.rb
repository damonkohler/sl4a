droid = Android.new
droid.makeToast "Hello, Android!"
