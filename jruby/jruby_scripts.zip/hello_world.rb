require "android"
droid = Droid.new
droid.makeToast "Hello, Android!"
