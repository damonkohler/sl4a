call import "android.r"
call AndroidInit
msg = "Hello, Android!"
call makeToast msg
say msg
